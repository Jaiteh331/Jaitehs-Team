import React, { useState } from 'react';
import { Users, Calendar, Clock, Trophy, Plus, MapPin, CheckCircle2 } from 'lucide-react';

// Types
interface Player {
  id: number;
  name: string;
  position: string;
  status: 'Active' | 'Injured' | 'Resting';
  attendanceRate: string;
}

interface TrainingSession {
  id: number;
  day: string;
  time: string;
  location: string;
  focusArea: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'roster' | 'training' | 'matchday'>('roster');

  // Initial Mock Data
  const [players] = useState<Player[]>([
    { id: 1, name: 'Player One', position: 'Forward', status: 'Active', attendanceRate: '95%' },
    { id: 2, name: 'Player Two', position: 'Midfielder', status: 'Active', attendanceRate: '88%' },
    { id: 3, name: 'Player Three', position: 'Defender', status: 'Resting', attendanceRate: '92%' },
    { id: 4, name: 'Player Four', position: 'Goalkeeper', status: 'Active', attendanceRate: '90%' },
  ]);

  const [trainings] = useState<TrainingSession[]>([
    { id: 1, day: 'Tuesday', time: '18:30 - 20:30', location: 'Pitch A (Main Ground)', focusArea: 'Tactical Drills & Pre-Season Fitness' },
    { id: 2, day: 'Thursday', time: '18:30 - 20:00', location: 'Pitch B', focusArea: 'Set Pieces & Ball Possession' },
    { id: 3, day: 'Saturday', time: '10:00 - 12:00', location: 'Gym / Field', focusArea: 'Strength & Agility' },
  ]);

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 font-sans">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-gray-800 border-r border-gray-700 flex flex-col justify-between p-4">
        <div>
          <div className="flex items-center space-x-3 mb-8 px-2">
            <div className="p-2 bg-emerald-500 rounded-lg text-gray-900 font-bold">JT</div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-wide leading-tight">Jaiteh’s Team</h1>
              <span className="text-xs text-gray-400">Get Teams App</span>
            </div>
          </div>

          <nav className="space-y-2">
            <button
              onClick={() => setActiveTab('roster')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition ${
                activeTab === 'roster' ? 'bg-emerald-500/10 text-emerald-400 font-semibold' : 'text-gray-400 hover:bg-gray-700/50'
              }`}
            >
              <Users className="w-5 h-5" />
              <span>Team Roster</span>
            </button>

            <button
              onClick={() => setActiveTab('training')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition ${
                activeTab === 'training' ? 'bg-emerald-500/10 text-emerald-400 font-semibold' : 'text-gray-400 hover:bg-gray-700/50'
              }`}
            >
              <Calendar className="w-5 h-5" />
              <span>Training Days</span>
            </button>

            <button
              onClick={() => setActiveTab('matchday')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition ${
                activeTab === 'matchday' ? 'bg-emerald-500/10 text-emerald-400 font-semibold' : 'text-gray-400 hover:bg-gray-700/50'
              }`}
            >
              <Trophy className="w-5 h-5" />
              <span>Matchday Planner</span>
            </button>
          </nav>
        </div>

        <div className="p-3 bg-gray-700/30 rounded-xl border border-gray-700/50">
          <p className="text-xs text-gray-400">Status</p>
          <div className="flex items-center space-x-2 mt-1">
            <div className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-gray-200">Pre-Season Ready</span>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-8">
        {/* Roster View */}
        {activeTab === 'roster' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold text-white">Jaiteh’s Team — Squad Roster</h2>
                <p className="text-gray-400 text-sm">Manage active players, positions, and attendance status.</p>
              </div>
              <button className="flex items-center space-x-2 bg-emerald-500 hover:bg-emerald-600 text-gray-900 px-4 py-2 rounded-lg font-medium transition">
                <Plus className="w-4 h-4" />
                <span>Add Member</span>
              </button>
            </div>

            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gray-700/50 text-gray-400 text-xs uppercase tracking-wider border-b border-gray-700">
                    <th className="p-4">Name</th>
                    <th className="p-4">Position</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Attendance Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700/50 text-sm">
                  {players.map((p) => (
                    <tr key={p.id} className="hover:bg-gray-700/30 transition">
                      <td className="p-4 font-medium text-white">{p.name}</td>
                      <td className="p-4 text-gray-300">{p.position}</td>
                      <td className="p-4">
                        <span
                          className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                            p.status === 'Active'
                              ? 'bg-emerald-500/10 text-emerald-400'
                              : p.status === 'Injured'
                              ? 'bg-rose-500/10 text-rose-400'
                              : 'bg-amber-500/10 text-amber-400'
                          }`}
                        >
                          {p.status}
                        </span>
                      </td>
                      <td className="p-4 text-gray-300">{p.attendanceRate}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Training View */}
        {activeTab === 'training' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold text-white">Training Schedule</h2>
                <p className="text-gray-400 text-sm">Upcoming sessions for Jaiteh’s Team.</p>
              </div>
              <button className="flex items-center space-x-2 bg-emerald-500 hover:bg-emerald-600 text-gray-900 px-4 py-2 rounded-lg font-medium transition">
                <Plus className="w-4 h-4" />
                <span>Schedule Session</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {trainings.map((t) => (
                <div key={t.id} className="bg-gray-800 border border-gray-700 rounded-xl p-5 hover:border-emerald-500/50 transition">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-md">
                      {t.day}
                    </span>
                    <div className="flex items-center text-xs text-gray-400 space-x-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{t.time}</span>
                    </div>
                  </div>
                  <h3 className="font-semibold text-white mb-2">{t.focusArea}</h3>
                  <div className="flex items-center text-xs text-gray-400 space-x-1">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{t.location}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Matchday Planner View */}
        {activeTab === 'matchday' && (
          <div>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white">Matchday Scheduler</h2>
              <p className="text-gray-400 text-sm">Key timeline and arrival details for upcoming fixtures.</p>
            </div>

            <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
              <div className="flex items-center justify-between border-b border-gray-700 pb-4 mb-6">
                <div>
                  <span className="text-xs font-bold text-emerald-400 tracking-wider uppercase">Next Match</span>
                  <h3 className="text-xl font-bold text-white mt-1">Jaiteh’s Team — Match 1</h3>
                </div>
                <div className="text-right">
                  <span className="text-sm font-semibold text-gray-300">Saturday, 09:00 AM</span>
                  <p className="text-xs text-gray-400">Tournament Grounds • Pitch 1</p>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-semibold text-gray-300">Arrival & Schedule</h4>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3 p-3 bg-gray-700/30 rounded-lg">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">08:15 AM — Team Arrival & Check-In</p>
                      <p className="text-xs text-gray-400">Everyone must arrive on time to meet at the designated area.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 p-3 bg-gray-700/30 rounded-lg">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">08:30 AM — Warm-Up & Briefing</p>
                      <p className="text-xs text-gray-400">Warm-up drills, stretching, and tactical instructions.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 p-3 bg-gray-700/30 rounded-lg">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">09:00 AM — Kickoff</p>
                      <p className="text-xs text-gray-400">First match begins.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
