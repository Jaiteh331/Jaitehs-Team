# Get Teams App — Jaiteh’s Team

A modern, streamlined management dashboard for Jaiteh’s Team to organize roster members, schedule training sessions, and coordinate matchday logistics.

## Features
- **Team Roster:** Track active team members, positions, and attendance rates.
- **Training Days:** Schedule recurring training sessions, times, and focus areas.
- **Matchday Scheduler:** Plan match timelines and arrival logistics for upcoming games.

## Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) (v18 or higher recommended)

### Setup & Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/YOUR_USERNAME/Get-Teams-App.git
   cd Get-Teams-App
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the local development server:
   ```bash
   npm run dev
   ```
